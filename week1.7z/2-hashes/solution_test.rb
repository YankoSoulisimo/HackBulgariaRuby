require 'minitest/autorun'

require_relative 'solution'

class HashTest < Minitest::Test
  def test_the_truth
    assert true
  end
end