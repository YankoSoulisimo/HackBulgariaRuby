class Hash

  def pick(*keys)
    picked = Hash.new
    keys.each do |key|
      picked[key] = self[key] if self.has_key?(key)
    end
    picked
  end

  def except(*keys)
    picked = Hash.new
    keys.each do |key|
      picked[key] = self[key] unless self.has_key?(key)
    end
    picked
  end

  def compact_values
    compact = Hash.new
    self.each do |key,value|
      compact[key] = value if value
    end
    compact
  end

  def defaults(hash)
    default = Hash.new
    self.each do |key,value|
      default[key] = value unless default.has_key?(key)
    end
    hash.each do |key,value|
      default[key] = value unless self.has_key?(key)
    end
    default
  end

end
