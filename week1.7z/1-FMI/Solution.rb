class Array
  def to_hash
  	hashes = self.map{ |pair| Hash[*pair] }
  	hashes.inject{ |h1,h2| h1.merge(h2){ |*a| a[1,2] } }
  end

  def occurrences_count
  	count_occurrences = Hash.new 0
	  self.each do |element|
	    count_occurrences[element] += 1
	  end
	  count_occurrences
  end

  def bubble_sort
    sorted = false
    until sorted
      sorted = true
      (self.count - 1).times do |i|
        if self[i] > self[i + 1]
          self[i], self[i + 1] = self[i + 1], self[i]
          sorted = false
        end
      end
    end
    self
  end
  
  def mergesort
    def merge(left_sorted, right_sorted)
      res = []
      l = 0
      r = 0
   
      loop do
        break if r >= right_sorted.length and l >= left_sorted.length
   
        if r >= right_sorted.length or (l < left_sorted.length and left_sorted[l] < right_sorted[r])
          res << left_sorted[l]
          l += 1
        else
          res << right_sorted[r]
          r += 1
        end
      end
   
      return res
    end
 
    def mergesort_iter(array_sliced)
      return array_sliced if array_sliced.length <= 1
   
      mid = array_sliced.length/2 - 1
      left_sorted = mergesort_iter(array_sliced[0..mid])
      right_sorted = mergesort_iter(array_sliced[mid+1..-1])
      return merge(left_sorted, right_sorted)
    end
 
    mergesort_iter(self)
  end

end

