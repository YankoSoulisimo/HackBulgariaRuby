FMI
2011 was a great year for Ruby. Colomb have just discovered the new earth, the first space shuffle has landed on Mars and the dinosaurs have just went MIA. In this great age of time, FMI had a great Ruby student, named Genadi.

Let me share my experience with you and present you with my first ever Ruby homework.

:kiss: to @skanev and @mitio for this one.

Resources

Enumerable is a gem. Go through its documentation. Array builds on top of it.

http://www.ruby-doc.org/core-2.1.3/Enumerable.html
http://www.ruby-doc.org/core-2.1.3/Array.html
Handycap

Avoid using Enumerable#each and you get a sticker :)