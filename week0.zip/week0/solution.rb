#histogram
def histogram(string)
  array = string.split('').map { |char| char }
  histogram = {}
  array.each { |item| histogram[item] = (histogram[item] || 0) + 1 }
  histogram
end

#prime
def prime?(n)
  (2..(n - 1)).each do |x|
     if (n % x) == 0
      return false
     end
  end
  true
end

#ordinal
def ordinal(n)
  if n % 10 == 1
    n.to_s + "st"
  elsif n % 10 == 2
    n.to_s + "nd"
  elsif n % 10 == 3
    n.to_s + "rd"
  else
    n.to_s + "th"
  end
end

#palindrome
def palindrome?(object)
  string = object.downcase.scan(/\w/)
  string == string.reverse
end

#anagram
def anagram?(word, other)
  word.chars.sort == other.chars.sort
end

#remove prefix
def remove_prefix(string, pattern)
  string.slice! pattern
  string.strip!
  string
end

#remove prefix
def remove_suffix(string, pattern)
  string.slice! pattern
  string.strip!
  string
end

#digits
def digits(n)
  n.to_s.split('').map { |digit| digit.to_i }
end

def fizzbuzz(range)
  result = Array.new
  (range).each do |n|
    if (n % 3 == 0) && (n % 5 == 0)
      result[n-1] = :fizzbuzz
    elsif (n % 3) == 0
      result[n-1] = :fizz
    elsif (n % 5) == 0
      result[n-1] = :buzz
    else
      result[n-1] = n
    end
  end
  result
end
