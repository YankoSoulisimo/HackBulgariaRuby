﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SinCosTaylor
{
    class SinCosTaylor
    {
        static void Main(string[] args)
        {
            for (double d = 0; d < 3.0; d += 0.4)
            {
                Console.WriteLine("The cosine of {0} = {1}", d, Math.Cos(d));
                Console.WriteLine("Calculated cosine of {0} = {1}", d, Cos(d, 7));
                Console.WriteLine("Calculated cosine of {0} = {1}", d, CosThroughSine(d));
                Console.WriteLine("The sine of {0} = {1}", d, Math.Sin(d));
                Console.WriteLine("Calculated sine of {0} = {1}", d, Sine(d, 7));
                Console.WriteLine("Calculated sine of {0} = {1}", d, SineThroughCos(d));
                Console.WriteLine();
            }
        }

        // calculate factorial
        static int Factorial(int n)
        {
            if (n <= 1)
                return 1;
            return n * Factorial(n - 1);
        }
        // calculate sine
        static double Sine(double x, int precisionStep)
        {
            double sign = -1; // use to change sign
            double sum = 0;   // formula sum
            for (int i = 1; i <= precisionStep; i++)
            {
                sum += sign * (Math.Pow(x, i * 2 + 1) / Factorial(i * 2 + 1));
                sign *= -1;
            }
            return x + sum;
        }
        //calculate cosine
        static double Cos(double x, int precisionStep) 
        {
            double sign = -1; // use to change sign
            double sum = 0;   // formula sum
            for (int i = 1; i <= precisionStep; i++)
            {
                sum += sign * (Math.Pow(x, i * 2) / Factorial(i * 2));
                sign *= -1;
            }
            return 1.0 + sum;
        }
        // calculate sine using cosine method
        static double SineThroughCos(double x)
        {
            return Cos(Math.PI / 2 - x, 10);
        }
        // calculate cosine using sine method
        static double CosThroughSine(double x)
        {
            return Sine(Math.PI / 2 - x, 10);
        }
    }
}
